export type RealTimeUpdate = {
  id: number;
  content: string;
  isActive: boolean;
};
