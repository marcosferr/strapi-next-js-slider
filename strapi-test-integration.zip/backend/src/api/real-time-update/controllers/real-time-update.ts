/**
 * real-time-update controller
 */

import { factories } from '@strapi/strapi'

export default factories.createCoreController('api::real-time-update.real-time-update');
