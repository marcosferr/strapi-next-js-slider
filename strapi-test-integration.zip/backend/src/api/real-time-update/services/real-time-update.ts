/**
 * real-time-update service
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreService('api::real-time-update.real-time-update');
